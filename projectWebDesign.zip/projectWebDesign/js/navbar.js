$(document).ready(function(){
    $('.hb-button').on('click', function(){
        $('.nav-max').toggleClass('show');
        $('li').toggleClass('li-show');
    });
});